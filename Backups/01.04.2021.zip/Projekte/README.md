[![Banner][Banner]](https://discord.gg/mDjs5VpNRE)
Dieser Ordner enthält alle Projekte der HTML Götter

Folgende Dateien sind in diesem Ordner:
* Erledigte Arbeitsaufträge
* Persönliche Projekte
* Beispieldateien zur freien Bedienung

[![Stripe][Stripe]](https://discord.gg/mDjs5VpNRE)


<!-- MARKDOWN LINKS & IMAGES -->
[Banner]: https://img.yorb.xyz/gotterbanner.png
[Stripe]: https://img.yorb.xyz/gotterstripe.png